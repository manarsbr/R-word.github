
# Plateforme de Traduction Algérienne

Ce projet est une démonstration simple d'un site web statique multilingue (Français / Anglais) pour la réservation de services de traduction.

## Fonctionnalités

- Page d'accueil multilingue
- Formulaire de réservation simple
- Changement dynamique de langue (FR / EN)

## Comment l'utiliser

1. Ouvrez `index.html` dans votre navigateur.
2. Cliquez sur "Français" ou "English" pour changer la langue.
3. Remplissez le formulaire de réservation (non connecté à une base de données pour l'instant).

## Déploiement GitHub Pages

- Créez un dépôt GitHub
- Téléversez les fichiers
- Activez GitHub Pages dans les paramètres

## À venir

- Système de réservation dynamique
- Authentification client/traducteur
- Paiement en ligne
